<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Biblioteca JGF</title>
</head>
<body>
    <table class="table-auto">
    <thead>
      <tr>
        <th>Titulo</th>
        <th rowspan="2">Acciones</th>
      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $libros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $libro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><a href="<?php echo e(route("libros.show", $libro)); ?>"><?php echo e($libro->titulo); ?></a></td>
              <td>
                <form action="<?php echo e(route("libros.edit", $libro)); ?>" method="GET">
                    <?php echo csrf_field(); ?>
                    <button type="submit"> Editar </button>
                </form>
            </td>
              <td>
                <form action="<?php echo e(route("libros.destroy", $libro)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("DELETE"); ?>
                    <button type="submit"> Borrar </button>
                </form>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <br>
  <a href="<?php echo e(route("libros.create")); ?>"> Añadir </a>
</body>
</html>
<?php /**PATH /home/jorge/biblioteca/resources/views/libros/index.blade.php ENDPATH**/ ?>