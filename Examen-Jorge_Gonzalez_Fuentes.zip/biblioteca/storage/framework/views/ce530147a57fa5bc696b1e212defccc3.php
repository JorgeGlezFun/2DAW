<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form action="<?php echo e(route("libros.update", $libro)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field("PUT"); ?>
        <label for="titulo">Titulo</label>
        <input type="text" name="titulo" id="titulo" value="<?php echo e($libro->titulo); ?>"><br>
        <button type="submit">Crear</button>
    </form>
</body>
</html>
<?php /**PATH /home/jorge/biblioteca/resources/views/libros/edit.blade.php ENDPATH**/ ?>