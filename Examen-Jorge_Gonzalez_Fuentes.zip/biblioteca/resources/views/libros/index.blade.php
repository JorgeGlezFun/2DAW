<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Biblioteca JGF</title>
</head>
<body>
    <table class="table-auto">
    <thead>
      <tr>
        <th>Titulo</th>
        <th rowspan="2">Acciones</th>
      </tr>
    </thead>
    <tbody>
        @foreach($libros as $libro)
            <tr>
              <td><a href="{{route("libros.show", $libro)}}">{{$libro->titulo}}</a></td>
              <td>
                <form action="{{route("libros.edit", $libro)}}" method="GET">
                    @csrf
                    <button type="submit"> Editar </button>
                </form>
            </td>
              <td>
                <form action="{{route("libros.destroy", $libro)}}" method="POST">
                    @csrf
                    @method("DELETE")
                    <button type="submit"> Borrar </button>
                </form>
              </td>
            </tr>
            @endforeach
    </tbody>
  </table>
  <br>
  <a href="{{route("libros.create")}}"> Añadir </a>
</body>
</html>
